// Austin Hall
// 6/4/19
// CSCD 300

public class LinkedList {

	private class Node{
		private Object data;   
		private Node next, prev;
		private Node(Object data, Node pref, Node next)
		{
			this.data = data;
			this.prev = pref;
			this.next = next;
		}
	}
	private Node head;
	private int size;

	public LinkedList() {
		this.head = new Node(null, null, null );
		this.head.next = this.head;
		this.head.prev=this.head;
		this.size = 0;
	}

	public boolean isEmpty() {
		return this.size == 0;
	} 
	
	public int getSize() {
		return this.size;
	}
	public void removeFirst() {
		this.head.next = this.head.next.next;
		this.head.next.prev = this.head;
		size--;
	}
	
	public void addLast(Object data) {
		Node nn = new Node(data, this.head.prev, this.head);
		this.head.prev.next = nn;
		this.head.prev = nn;
		this.size++;
	}
	
	public void addFirst(Object data) {
		Node nn = new Node(data, this.head, this.head.next);
		this.head.next.prev = nn;
		this.head.next = nn;
		this.size ++;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static LinkedList merge(LinkedList a, LinkedList b) {
		LinkedList c = new LinkedList();
		Node fa = a.head.next;
		Node fb = b.head.next;
		
		// Analyzes the first node in the list against the first node in the other list,
		// then adds the smaller node into a new list and removes it from the list it
		// originally came from
		while(!a.isEmpty() && !b.isEmpty()) {
			
			if(((Comparable)fa.data).compareTo(fb.data) < 0) {
				c.addLast(fa.data);
				a.removeFirst();
				fa = fa.next;
			} else {
				c.addLast(fb.data);
				b.removeFirst();
				fb = fb.next;
			}
			
		}
		
		// Once one list has all of its nodes taken out and sorted into the new list
		// we add the remaining nodes from the other list into the new list
		while(!a.isEmpty()) {
			c.addLast(fa.data);
			a.removeFirst();
			fa = fa.next;
			
		}
		while(!b.isEmpty()) {
			c.addLast(fb.data);
			b.removeFirst();
			fb = fb.next;
		}
		return c;
	}
	
	public void mergeSort() throws Exception {
		Queue q = new Queue();
		// Creates a new Linked list that contains the node at curr for each node in the list
		for(Node curr = this.head.next; curr != this.head; curr = curr.next) {
			LinkedList newList = new LinkedList();
			newList.addFirst(curr.data);
			// Adds each new linked list to a queue
			q.enque(newList);
		}
		while(q.moreThanTwo()) {
			LinkedList sublist1 = (LinkedList) q.dequeue();
			LinkedList sublist2 = (LinkedList) q.dequeue(); 
			// The temp list is the sorted merge of the top two lists in the queue
			LinkedList tempList = merge(sublist1, sublist2);
			// Add this sorted list back into queue and will be added to on the next run
			q.enque(tempList);
		}
		// When there is only one list left in the queue, we know that this is the final
		// sorted list so we point this list head to tempList head
		LinkedList tempList = (LinkedList) q.dequeue();
		this.head = tempList.head;
	}
	
	public boolean isSorted() {
		// Traverses the linked list and if the node after the current node is smaller, 
		// returns false because that means it isn't sorted
		for(Node curr = this.head.next; curr.next != this.head; curr = curr.next) {
			if(((Comparable) curr.data).compareTo(curr.next.data) > 0) {
				return false;
			}
		}
		return true;
	}
	
	public void insertionSort() {
		Node prevSort, cur;
		Comparable firstUnsort;
		// This iterates through the "unsorted" part of the list
		for (prevSort = this.head.next; prevSort != this.head.prev; prevSort = prevSort.next) {
			// the next element in the unsorted part
			firstUnsort = (Comparable) prevSort.next.data;
			// This goes through the "sorted" part of the list searching for when cur is less than the
			// newest addition to the sorted list
			for (cur = prevSort; cur != this.head && ((Comparable) cur.data).compareTo(firstUnsort) > 0; cur = cur.prev) {
				cur.next.data = cur.data;
			}
			// Once its found, its added in
			cur.next.data = firstUnsort;
		}
	}
	
	public String toString() {
		String result = "";
		for (Node curr = this.head.next; curr != this.head; curr = curr.next) {
			result += curr.data + "-->";

		}
		return result;
	}
}
