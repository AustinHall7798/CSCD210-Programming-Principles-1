// Austin Hall
// 6/4/19
// CSCD 300

public class Queue {
	private class Node {
		private Object data;
		private Node next;

		public Node(Object item) {
			this.data = item;
			this.next = null;
		}
	}

	private Node head, tail;
	private int size;

	public Queue() { // Create empty queue
		this.head = null;
		this.tail = null;
		this.size = 0;
	}
	
	// Used in merge sort method to ensure there won't be nullPointerException
	public boolean moreThanTwo() {
		return this.size >= 2;
	}
	
	public void enque(Object elem) {
	
		Node nn = new Node(elem);
		if(this.size == 0) {
			this.head = nn;
		}
		else {
			this.tail.next = nn;
		}
		this.tail = nn;
		this.size++;
	}

	
	public Object dequeue() throws Exception{
		if(this.size == 0) {
			throw new Exception("empty queue");
		}
		Object temp = this.head.data;
		this.head = this.head.next;
		this.size--;
		if(this.size == 0) {
			this.tail = null;
		}
		return temp;
	}
}
